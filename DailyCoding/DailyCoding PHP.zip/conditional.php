<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>WEB</h1>
    <ol>
        <li><a href="index.php?id=HTML">HTML</a></li>
        <li><a href="index.php?id=CSS">CSS</a></li>
        <li><a href="index.php?id=JavaScript">JavaScript</a></li>
    </ol>
    <ol>
    
        <?php

        $html = scandir('./');
        print_r($html);
        $i=2;
        while($i<count($html)){
            echo "<li><a href=\"index.php?id=$html[$i]\">$html[$i]</a></li>";
            $i = $i+1;
        }
        ?>
    </ol>
</body> 
</html>