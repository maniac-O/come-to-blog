<?php
$conn = mysqli_connect("localhost", "root", "root", "opentutorials");
$sql = "
    INSERT INTO topic(a, description, created)
    VALUE('MySQL','MySQL is ..',NOW())";

$result = mysqli_query($conn,$sql);
if($result === false){
    echo mysqli_error($conn);
}
?>
